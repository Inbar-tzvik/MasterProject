$('#header').load('../includes/header.html')
$('#header').load('../includes/headerHomePage.html')

$('#footer').load('../includes/footer.html')