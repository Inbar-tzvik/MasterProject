
<?php
$server_name = "localhost";
$username = "maycois";
$password = "WwSVtsJ1pMl6";
$database = "maycois_MasterProject";


$conn = new mysqli($server_name, $username, $password, $database);

//if ($conn->connect_error) {
  //  die("Connection failed: " . $conn->connect_error);
//}
//echo "Connection successful";
$sql = "SELECT *  FROM roles2";
$result = mysqli_query($conn,$sql);?>

<html>
<head>
<meta charset="UTF-8">
<title>Document</title>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['course', 'number'],<?php
          if(mysqli_num_rows($result)>0){
              while($row=mysqli_fetch_array($result)){
                  echo"['".$row['course']."',".$row['number']."],";
             }
          }
        ?>
        ]);

        var options = {
          title: 'My Daily Activities'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart" style="width: 100%; height: 100%;"></div>
  </body>

</html>
